"""
ui/custom_widgets.py
~~~~~~~~~~~~~~~~~~~~
Custom dark-themed widgets to match the design.
"""

from PyQt6.QtCore import (
    QEasingCurve,
    QPoint,
    QPropertyAnimation,
    QRect,
    Qt,
    pyqtProperty,
    pyqtSignal,
)
from PyQt6.QtGui import QColor, QPainter, QPaintEvent
from PyQt6.QtWidgets import QWidget


class ToggleSwitch(QWidget):
    """
    A custom iOS-style toggle switch.
    """
    toggled = pyqtSignal(bool)

    def __init__(self, parent=None, track_radius=12, thumb_radius=10):
        super().__init__(parent)
        self.setFixedSize(48, 24)

        self._track_radius = track_radius
        self._thumb_radius = thumb_radius
        self._margin = 2

        self._is_checked = False

        # Colors corresponding to the dark theme mockup
        self._bg_color_off = QColor("#2a2a30")
        self._bg_color_on = QColor("#3f8cff")
        self._thumb_color = QColor("#ffffff")

        self._pos_off = self._margin
        self._pos_on = self.width() - self._thumb_radius * 2 - self._margin
        
        # Animatable property
        self._thumb_pos = self._pos_off

        self._anim = QPropertyAnimation(self, b"thumb_pos", self)
        self._anim.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._anim.setDuration(150)

    @pyqtProperty(int)
    def thumb_pos(self):
        return self._thumb_pos

    @thumb_pos.setter
    def thumb_pos(self, pos):
        self._thumb_pos = pos
        self.update()

    def isChecked(self):
        return self._is_checked

    def setChecked(self, checked, animate=True):
        if self._is_checked == checked:
            return
            
        self._is_checked = checked
        end_pos = self._pos_on if checked else self._pos_off
        
        if animate:
            self._anim.stop()
            self._anim.setStartValue(self._thumb_pos)
            self._anim.setEndValue(end_pos)
            self._anim.start()
        else:
            self.thumb_pos = end_pos
            
        self.toggled.emit(self._is_checked)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.setChecked(not self._is_checked)
        super().mouseReleaseEvent(event)

    def paintEvent(self, event: QPaintEvent):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Draw track
        bg_color = self._bg_color_on if self._is_checked else self._bg_color_off
        # Optionally, transition color smoothly: (simplification for steady states)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg_color)
        p.drawRoundedRect(0, 0, self.width(), self.height(), self._track_radius, self._track_radius)

        # Draw thumb
        thumb_rect = QRect(
            self._thumb_pos,
            self._margin,
            self._thumb_radius * 2,
            self._thumb_radius * 2
        )
        p.setBrush(self._thumb_color)
        p.drawEllipse(thumb_rect)
        p.end()
