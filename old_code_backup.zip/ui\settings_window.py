"""
ui/settings_window.py
~~~~~~~~~~~~~~~~~~~~~
SettingsWindow: the persistent settings UI for HoverDesk.
Contains ONLY UI code — all logic is delegated to HoverEngine / ConfigStore.

Redesigned for a modern dark theme with iOS-style toggles and a sleek layout.
"""

from __future__ import annotations

import ctypes
import os
import sys
from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QRadioButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from ui.custom_widgets import ToggleSwitch

if TYPE_CHECKING:
    from core.config import ConfigStore
    from core.engine import HoverEngine


# ---------------------------------------------------------------------------
# Stylesheets
# ---------------------------------------------------------------------------

WINDOW_STYLE = """
    QWidget#SettingsWindow {
        background-color: #1a1a24;
        border-radius: 12px;
        border: 1px solid #2a2a35;
    }
    QLabel {
        color: #ffffff;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    QLabel#Title {
        font-size: 16px;
        font-weight: 600;
    }
    QLabel#SectionTitle {
        font-size: 15px;
        font-weight: 500;
    }
    QLabel#Subtext {
        color: #8b8b9b;
        font-size: 13px;
    }
    QLabel#Warning {
        color: #f59e0b;
        font-size: 12px;
    }
    QFrame#Divider {
        background-color: #2a2a35;
    }
"""

SLIDER_STYLE = """
    QSlider::groove:horizontal {
        border-radius: 3px;
        height: 6px;
        margin: 0px;
        background-color: #2a2a30;
    }
    QSlider::sub-page:horizontal {
        background: #3f8cff;
        border-radius: 3px;
    }
    QSlider::handle:horizontal {
        background: #5fa4ff;
        border: 2px solid #3f8cff;
        width: 14px;
        height: 14px;
        margin: -4px 0;
        border-radius: 9px;
    }
    QSlider::handle:horizontal:hover {
        background: #ffffff;
        border: 2px solid #5fa4ff;
    }
"""

RADIO_STYLE = """
    QRadioButton {
        color: #8b8b9b;
        font-size: 14px;
        spacing: 8px;
    }
    QRadioButton::indicator {
        width: 18px;
        height: 18px;
        border-radius: 10px;
        border: 2px solid #3f3f4c;
        background-color: transparent;
    }
    QRadioButton::indicator:checked {
        border: 2px solid #3f8cff;
        background-color: #3f8cff;
    }
    QRadioButton::indicator:checked:disabled {
        border: 2px solid #555;
        background-color: #777;
    }
"""

BUTTON_PRIMARY_STYLE = """
    QPushButton {
        background-color: #3f8cff;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 0;
    }
    QPushButton:hover {
        background-color: #5fa4ff;
    }
    QPushButton:pressed {
        background-color: #2b6ad0;
    }
"""

BUTTON_SECONDARY_STYLE = """
    QPushButton {
        background-color: #2a2a35;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 0;
    }
    QPushButton:hover {
        background-color: #353545;
    }
    QPushButton:pressed {
        background-color: #20202a;
    }
"""

TITLE_BTN_STYLE = """
    QPushButton {
        background: transparent;
        color: #8b8b9b;
        font-size: 16px;
        font-weight: bold;
    }
    QPushButton:hover {
        color: #ffffff;
    }
"""


class SettingsWindow(QWidget):
    """
    Persistent settings window matching the dark-theme mockup.
    Frameless window hint is used to allow rounded corners.
    """

    def __init__(self, engine: "HoverEngine", config_store: "ConfigStore") -> None:
        super().__init__()
        self._engine = engine
        self._store = config_store

        self.setObjectName("SettingsWindow")
        self.setWindowTitle("HoverDesk Settings")
        self.setFixedSize(540, 420)

        # Frameless window for custom rounded styling - NO Tool, NO Popup, NO WindowStaysOnTopHint
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.FramelessWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # To support dragging the frameless window
        self._dragging = False
        self._drag_start_pos = None

        self._build_ui()
        self.setStyleSheet(WINDOW_STYLE)
        self._load_from_config()

    # ------------------------------------------------------------------
    # Dragging logic for frameless window
    # ------------------------------------------------------------------

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            # Only allow drag from the top title area (~40px)
            if event.position().y() < 60:
                self._dragging = True
                self._drag_start_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging and self._drag_start_pos is not None:
            self.move(event.globalPosition().toPoint() - self._drag_start_pos)
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._dragging = False
        super().mouseReleaseEvent(event)

    # ------------------------------------------------------------------
    # UI Construction
    # ------------------------------------------------------------------

    def _make_divider(self) -> QFrame:
        line = QFrame()
        line.setObjectName("Divider")
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Plain)
        line.setFixedHeight(1)
        return line

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Inner container for the background and rounded border
        container = QWidget(self)
        container.setObjectName("SettingsWindow")
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(24, 20, 24, 24)
        container_layout.setSpacing(0)
        root.addWidget(container)

        # --- Custom Title Bar ---
        title_row = QHBoxLayout()
        title_label = QLabel("HoverDesk Settings")
        title_label.setObjectName("Title")
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(24, 24)
        close_btn.setStyleSheet(TITLE_BTN_STYLE)
        close_btn.clicked.connect(self.hide)

        title_row.addWidget(title_label)
        title_row.addStretch(1)
        title_row.addWidget(close_btn)
        container_layout.addLayout(title_row)
        
        container_layout.addSpacing(30)

        # --- Section 1: Idle Time ---
        idle_header_row = QHBoxLayout()
        idle_title = QLabel("Idle Time")
        idle_title.setObjectName("SectionTitle")
        
        # Value pill layout (like the mockup's right side label)
        self._idle_value_label = QLabel("10 seconds")
        self._idle_value_label.setStyleSheet("background-color: #2a2a35; padding: 4px 10px; border-radius: 6px;")
        
        idle_header_row.addWidget(idle_title)
        idle_header_row.addStretch(1)
        idle_header_row.addWidget(self._idle_value_label)
        
        idle_desc = QLabel("Time to hide icons when idle")
        idle_desc.setObjectName("Subtext")
        
        self._idle_slider = QSlider(Qt.Orientation.Horizontal)
        self._idle_slider.setStyleSheet(SLIDER_STYLE)
        self._idle_slider.setMinimum(1)
        self._idle_slider.setMaximum(30)
        self._idle_slider.valueChanged.connect(
            lambda v: self._idle_value_label.setText(f"{v} seconds")
        )

        container_layout.addLayout(idle_header_row)
        container_layout.addSpacing(4)
        container_layout.addWidget(idle_desc)
        container_layout.addSpacing(16)
        container_layout.addWidget(self._idle_slider)
        container_layout.addSpacing(24)

        # --- Section 2: Enabled ---
        container_layout.addWidget(self._make_divider())
        container_layout.addSpacing(20)

        enabled_row = QHBoxLayout()
        enabled_title = QLabel("Enabled")
        enabled_title.setObjectName("SectionTitle")
        self._enable_toggle = ToggleSwitch(self)
        
        enabled_row.addWidget(enabled_title)
        enabled_row.addStretch(1)
        enabled_row.addWidget(self._enable_toggle)
        container_layout.addLayout(enabled_row)
        
        container_layout.addSpacing(20)

        # --- Section 3: Start With Windows ---
        container_layout.addWidget(self._make_divider())
        container_layout.addSpacing(20)

        startup_row = QHBoxLayout()
        startup_title = QLabel("Start With Windows")
        startup_title.setObjectName("SectionTitle")
        self._startup_toggle = ToggleSwitch(self)
        
        startup_row.addWidget(startup_title)
        startup_row.addStretch(1)
        startup_row.addWidget(self._startup_toggle)
        container_layout.addLayout(startup_row)
        
        container_layout.addSpacing(20)
        container_layout.addWidget(self._make_divider())
        container_layout.addSpacing(20)

        # --- Section 4: Mode ---
        mode_title = QLabel("Mode")
        mode_title.setObjectName("SectionTitle")
        container_layout.addWidget(mode_title)
        container_layout.addSpacing(12)

        radio_row = QHBoxLayout()
        self._safe_radio = QRadioButton("Normal Mode (Safe)")
        self._exp_radio = QRadioButton("Fade Mode (Experimental)")
        self._safe_radio.setStyleSheet(RADIO_STYLE)
        self._exp_radio.setStyleSheet(RADIO_STYLE)

        self._mode_group = QButtonGroup(self)
        self._mode_group.addButton(self._safe_radio)
        self._mode_group.addButton(self._exp_radio)
        
        radio_row.addWidget(self._safe_radio)
        radio_row.addSpacing(20)
        radio_row.addWidget(self._exp_radio)
        radio_row.addStretch(1)
        container_layout.addLayout(radio_row)

        container_layout.addStretch(1)

        # --- Button Row ---
        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        
        self._ok_btn = QPushButton("OK")
        self._ok_btn.setFixedSize(100, 36)
        self._ok_btn.setStyleSheet(BUTTON_PRIMARY_STYLE)
        self._ok_btn.clicked.connect(self._on_ok)
        
        self._cancel_btn = QPushButton("Cancel")
        self._cancel_btn.setFixedSize(100, 36)
        self._cancel_btn.setStyleSheet(BUTTON_SECONDARY_STYLE)
        self._cancel_btn.clicked.connect(self.hide)
        
        btn_row.addWidget(self._ok_btn)
        btn_row.addSpacing(12)
        btn_row.addWidget(self._cancel_btn)
        
        container_layout.addLayout(btn_row)

    # ------------------------------------------------------------------
    # Config sync & logic
    # ------------------------------------------------------------------

    def _load_from_config(self) -> None:
        """Populate controls from the current config on disk."""
        from core.config import ConfigStore
        cfg = self._store.load()

        # Update without animating
        self._enable_toggle.setChecked(cfg.enabled, animate=False)
        self._idle_slider.setValue(cfg.idle_time)
        self._idle_value_label.setText(f"{cfg.idle_time} seconds")

        if cfg.mode == "experimental":
            self._exp_radio.setChecked(True)
        else:
            self._safe_radio.setChecked(True)

        self._startup_toggle.setChecked(self._store.get_startup(), animate=False)

    def _on_ok(self) -> None:
        """Save config, update engine, and close window."""
        from core.config import AppConfig

        mode = "experimental" if self._exp_radio.isChecked() else "safe"
        cfg = AppConfig(
            mode=mode,
            idle_time=self._idle_slider.value(),
            enabled=self._enable_toggle.isChecked(),
            startup=self._startup_toggle.isChecked(),
        )
        self._store.save(cfg)

        # Update startup registry
        exe = os.path.abspath(sys.argv[0])
        self._store.set_startup(cfg.startup, exe)

        # Push changes into running engine
        self._engine.reload_config()
        self.hide()

    # ------------------------------------------------------------------
    # Trigger / Focus
    # ------------------------------------------------------------------

    def show_and_focus(self) -> None:
        """Reload config to discard any unsaved changes, then bring forth."""
        self._load_from_config()
        
        # Explicitly clear minimized state before showing
        new_state = self.windowState() & ~Qt.WindowState.WindowMinimized
        new_state |= Qt.WindowState.WindowActive
        self.setWindowState(new_state)

        self.show()
        self.raise_()
        self.activateWindow()

        try:
            hwnd = int(self.winId())
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
