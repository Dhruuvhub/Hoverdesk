"""
core/config.py
~~~~~~~~~~~~~~
Handles loading and saving the HoverDesk JSON configuration.
Auto-creates the config file with defaults if it is missing.
"""

from __future__ import annotations

import json
import os
import winreg
from dataclasses import asdict, dataclass, field
from typing import Any

APP_NAME = "HoverDesk"
CONFIG_FILENAME = "hoverdesk_config.json"
STARTUP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def _app_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__ if "__file__" in dir() else "."))


def _config_path() -> str:
    # Config file lives next to the project root, not inside core/
    return os.path.join(os.path.dirname(_app_dir()), CONFIG_FILENAME)


@dataclass
class AppConfig:
    mode: str = "safe"          # "safe" | "experimental"
    idle_time: int = 3          # seconds before icons hide
    enabled: bool = True        # whether HoverDesk is active
    startup: bool = False       # launch at Windows startup


_DEFAULTS: dict[str, Any] = {
    "mode": "safe",
    "idle_time": 3,
    "enabled": True,
    "startup": False,
}


class ConfigStore:
    """Loads and persists AppConfig to/from JSON on disk."""

    def __init__(self) -> None:
        self._path = _config_path()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self) -> AppConfig:
        """Return AppConfig from disk, creating a default file if absent."""
        if not os.path.exists(self._path):
            cfg = AppConfig()
            self.save(cfg)
            return cfg
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data: dict[str, Any] = json.load(f)
            return self._parse(data)
        except Exception:
            return AppConfig()

    def save(self, cfg: AppConfig) -> None:
        """Atomically write config to disk."""
        data = asdict(cfg)
        tmp = self._path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, self._path)

    # ------------------------------------------------------------------
    # Registry helpers (startup toggle)
    # ------------------------------------------------------------------

    @staticmethod
    def set_startup(enabled: bool, exe_path: str) -> None:
        """Add or remove the app from the Windows startup registry key."""
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                STARTUP_REG_KEY,
                0,
                winreg.KEY_SET_VALUE,
            )
            if enabled:
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, exe_path)
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
        except Exception:
            pass

    @staticmethod
    def get_startup() -> bool:
        """Return True if the app is registered to run at startup."""
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                STARTUP_REG_KEY,
                0,
                winreg.KEY_READ,
            )
            winreg.QueryValueEx(key, APP_NAME)
            winreg.CloseKey(key)
            return True
        except FileNotFoundError:
            return False
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _parse(data: dict[str, Any]) -> AppConfig:
        mode = str(data.get("mode", _DEFAULTS["mode"])).strip().lower()
        if mode not in ("safe", "experimental"):
            mode = "safe"

        raw_idle = data.get("idle_time", _DEFAULTS["idle_time"])
        try:
            idle_time = max(1, min(300, int(raw_idle)))
        except (TypeError, ValueError):
            idle_time = int(_DEFAULTS["idle_time"])

        enabled = bool(data.get("enabled", _DEFAULTS["enabled"]))
        startup = bool(data.get("startup", _DEFAULTS["startup"]))

        return AppConfig(mode=mode, idle_time=idle_time, enabled=enabled, startup=startup)
