"""
core/engine.py
~~~~~~~~~~~~~~
HoverEngine: idle detection, desktop-icon visibility control,
and the safe / experimental fade modes.

This module contains all Win32 interaction — NO UI code lives here.
"""

from __future__ import annotations

import ctypes
import ctypes.wintypes
from typing import Optional

import win32con
import win32gui

from PyQt6.QtCore import QEasingCurve, QObject, QPropertyAnimation, QTimer, pyqtProperty

from core.config import AppConfig, ConfigStore

# ---------------------------------------------------------------------------
# Tunable constants
# ---------------------------------------------------------------------------
CHECK_INTERVAL_MS = 200      # >= 200 ms as per performance constraints
FADE_DURATION_MS = 400
SHOW_IDLE_THRESHOLD = 0.5    # seconds of activity before icons reappear


# ---------------------------------------------------------------------------
# Win32 helpers (module-level, no global state)
# ---------------------------------------------------------------------------

def get_idle_time_seconds() -> float:
    """Return seconds since last user input (keyboard or mouse)."""

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    lii = LASTINPUTINFO()
    lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
    ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
    millis = ctypes.windll.kernel32.GetTickCount64() - lii.dwTime
    return float(millis) / 1000.0


def is_cursor_on_desktop() -> bool:
    """Return True if the mouse cursor is over a desktop window class."""
    pt = ctypes.wintypes.POINT()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
    hwnd = win32gui.WindowFromPoint((pt.x, pt.y))
    try:
        class_name = win32gui.GetClassName(hwnd)
    except Exception:
        return False
    return class_name in ("WorkerW", "Progman", "SHELLDLL_DefView", "SysListView32")


def _find_desktop_listview_hwnd() -> int:
    """
    Locate the SysListView32 that backs desktop icons.
    Works for common Windows configurations where SHELLDLL_DefView lives
    under Progman or WorkerW.
    """
    progman = win32gui.FindWindow("Progman", None)
    if progman:
        defview = win32gui.FindWindowEx(progman, None, "SHELLDLL_DefView", None)
        if defview:
            listview = win32gui.FindWindowEx(defview, None, "SysListView32", None)
            if listview:
                return listview

    found: dict[str, int] = {"hwnd": 0}

    def _enum_cb(hwnd: int, _lparam: int) -> bool:
        try:
            class_name = win32gui.GetClassName(hwnd)
        except Exception:
            return True
        if class_name == "WorkerW":
            defview = win32gui.FindWindowEx(hwnd, None, "SHELLDLL_DefView", None)
            if defview:
                listview = win32gui.FindWindowEx(defview, None, "SysListView32", None)
                if listview:
                    found["hwnd"] = listview
                    return False
        return True

    win32gui.EnumWindows(_enum_cb, None)
    return found["hwnd"]


def _get_window_exstyle(hwnd: int) -> int:
    return int(win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE))


def _set_window_exstyle(hwnd: int, exstyle: int) -> None:
    win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, exstyle)


def _set_layered_alpha(hwnd: int, alpha_0_255: int) -> None:
    alpha = max(0, min(255, int(alpha_0_255)))
    win32gui.SetLayeredWindowAttributes(hwnd, 0, alpha, win32con.LWA_ALPHA)


# ---------------------------------------------------------------------------
# Qt animation driver
# ---------------------------------------------------------------------------

class _OpacityDriver(QObject):
    """Thin QObject wrapper so QPropertyAnimation can drive Win32 alpha blending."""

    def __init__(self, hwnd: int) -> None:
        super().__init__()
        self._hwnd = hwnd
        self._alpha = 255

    def _get_alpha(self) -> int:
        return self._alpha

    def _set_alpha(self, value: int) -> None:
        self._alpha = int(value)
        if self._hwnd:
            _set_layered_alpha(self._hwnd, self._alpha)

    alpha = pyqtProperty(int, fget=_get_alpha, fset=_set_alpha)


# ---------------------------------------------------------------------------
# Desktop icons controller
# ---------------------------------------------------------------------------

class DesktopIconsController(QObject):
    """
    Low-level controller for the desktop SysListView32 window.

    Safe mode  : uses only ShowWindow — no style changes, wallpaper stays.
    Experimental: temporarily applies WS_EX_LAYERED for smooth fade,
                  always restoring the original extended style afterwards.
    """

    def __init__(self) -> None:
        super().__init__()
        self.hwnd: int = 0
        self.icons_hidden: bool = False
        self._anim: Optional[QPropertyAnimation] = None
        self._opacity_driver: Optional[_OpacityDriver] = None
        self._restore_exstyle: Optional[int] = None

    # ------------------------------------------------------------------
    # Handle management
    # ------------------------------------------------------------------

    def refresh_handle(self) -> bool:
        self.hwnd = int(_find_desktop_listview_hwnd())
        self._opacity_driver = _OpacityDriver(self.hwnd) if self.hwnd else None
        return bool(self.hwnd)

    # ------------------------------------------------------------------
    # Safe-mode operations (NO layered style)
    # ------------------------------------------------------------------

    def safe_hide(self) -> None:
        """Hide icons using SW_HIDE only — no style modifications."""
        self._cleanup_experimental()
        if not self.hwnd:
            self.refresh_handle()
        if self.hwnd:
            win32gui.ShowWindow(self.hwnd, win32con.SW_HIDE)
            self.icons_hidden = True

    def safe_show(self) -> None:
        """Show icons using SW_SHOW only — no style modifications."""
        self._cleanup_experimental()
        if not self.hwnd:
            self.refresh_handle()
        if self.hwnd:
            win32gui.ShowWindow(self.hwnd, win32con.SW_SHOW)
            self.icons_hidden = False

    # ------------------------------------------------------------------
    # Experimental fade operations
    # ------------------------------------------------------------------

    def fade_hide(self) -> None:
        """
        Experimental: apply WS_EX_LAYERED, animate alpha 255→0, then SW_HIDE,
        then restore original extended style.
        """
        if not self.hwnd:
            self.refresh_handle()
        if not self.hwnd or not self._opacity_driver:
            return
        if self.icons_hidden:
            return

        self._stop_animation_and_restore_style()

        self._restore_exstyle = _get_window_exstyle(self.hwnd)
        _set_window_exstyle(self.hwnd, self._restore_exstyle | win32con.WS_EX_LAYERED)
        _set_layered_alpha(self.hwnd, 255)

        anim = QPropertyAnimation(self._opacity_driver, b"alpha", self)
        anim.setDuration(FADE_DURATION_MS)
        anim.setStartValue(255)
        anim.setEndValue(0)
        anim.setEasingCurve(QEasingCurve.Type.InOutQuad)

        def _on_finished() -> None:
            try:
                win32gui.ShowWindow(self.hwnd, win32con.SW_HIDE)
                self.icons_hidden = True
            finally:
                self._stop_animation_and_restore_style()

        anim.finished.connect(_on_finished)
        self._anim = anim
        anim.start()

    def fade_show(self) -> None:
        """
        Experimental: SW_SHOW icons, apply WS_EX_LAYERED, animate alpha 0→255,
        then restore original extended style.
        """
        if not self.hwnd:
            self.refresh_handle()
        if not self.hwnd or not self._opacity_driver:
            return
        if not self.icons_hidden:
            return

        self._stop_animation_and_restore_style()

        self._restore_exstyle = _get_window_exstyle(self.hwnd)
        _set_window_exstyle(self.hwnd, self._restore_exstyle | win32con.WS_EX_LAYERED)

        win32gui.ShowWindow(self.hwnd, win32con.SW_SHOW)
        _set_layered_alpha(self.hwnd, 0)

        anim = QPropertyAnimation(self._opacity_driver, b"alpha", self)
        anim.setDuration(FADE_DURATION_MS)
        anim.setStartValue(0)
        anim.setEndValue(255)
        anim.setEasingCurve(QEasingCurve.Type.InOutQuad)

        def _on_finished() -> None:
            try:
                _set_layered_alpha(self.hwnd, 255)
                self.icons_hidden = False
            finally:
                self._stop_animation_and_restore_style()

        anim.finished.connect(_on_finished)
        self._anim = anim
        anim.start()

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _stop_animation_and_restore_style(self) -> None:
        """Stop any running animation and restore original window extended style."""
        if self._anim:
            try:
                self._anim.stop()
            except Exception:
                pass
            self._anim = None

        if self.hwnd and self._restore_exstyle is not None:
            try:
                _set_layered_alpha(self.hwnd, 255)
            except Exception:
                pass
            try:
                _set_window_exstyle(self.hwnd, self._restore_exstyle)
            except Exception:
                pass
        self._restore_exstyle = None

    def _cleanup_experimental(self) -> None:
        """Called when switching to safe mode or on exit to restore original style."""
        if not self.hwnd:
            self.refresh_handle()
        self._stop_animation_and_restore_style()

    def force_show_and_cleanup(self) -> None:
        """Show icons and fully restore any experimental style — used by shutdown."""
        if not self.hwnd:
            self.refresh_handle()
        self._stop_animation_and_restore_style()
        if self.hwnd:
            win32gui.ShowWindow(self.hwnd, win32con.SW_SHOW)
            self.icons_hidden = False


# ---------------------------------------------------------------------------
# HoverEngine — the public API consumed by hoverdesk.py
# ---------------------------------------------------------------------------

class HoverEngine(QObject):
    """
    Coordinates idle detection and desktop icon hide/show behaviour.

    Reads config at every tick so runtime config changes (via Apply) take
    effect without restarting the engine.
    """

    def __init__(self, config_store: ConfigStore) -> None:
        super().__init__()
        self._store = config_store
        self._cfg: AppConfig = self._store.load()
        self._controller = DesktopIconsController()
        self._controller.refresh_handle()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self.check_idle)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Begin idle monitoring."""
        self._cfg = self._store.load()
        if not self._timer.isActive():
            self._timer.start(CHECK_INTERVAL_MS)

    def stop(self) -> None:
        """Pause idle monitoring and ensure icons are visible."""
        self._timer.stop()
        self._controller.force_show_and_cleanup()

    def shutdown(self) -> None:
        """Full cleanup on app exit — always restores icons."""
        try:
            self._timer.stop()
            self._controller._cleanup_experimental()
        finally:
            self._controller.force_show_and_cleanup()

    # ------------------------------------------------------------------
    # Runtime config update
    # ------------------------------------------------------------------

    def reload_config(self) -> None:
        """Re-read config from disk and adjust behaviour accordingly."""
        old_mode = self._cfg.mode
        self._cfg = self._store.load()

        if not self._cfg.enabled:
            self.stop()
            return

        # If switching away from experimental, clean up layered style first.
        if old_mode == "experimental" and self._cfg.mode != "experimental":
            self._controller._cleanup_experimental()

        if not self._timer.isActive():
            self._timer.start(CHECK_INTERVAL_MS)

    def set_mode(self, mode: str) -> None:
        """Switch mode at runtime (called directly from UI without saving)."""
        mode = mode.strip().lower()
        if mode not in ("safe", "experimental"):
            mode = "safe"
        if mode == self._cfg.mode:
            return
        # Clean up before switching modes.
        self._controller._cleanup_experimental()
        self._cfg.mode = mode

    # ------------------------------------------------------------------
    # Exposed mode runners (for external testing / extension)
    # ------------------------------------------------------------------

    def run_safe_mode(self) -> None:
        """Hide icons via safe (SW_HIDE only) method."""
        self._controller.safe_hide()

    def run_experimental_mode(self) -> None:
        """Hide icons via fade animation (experimental)."""
        self._controller.fade_hide()

    # ------------------------------------------------------------------
    # Tick (called by QTimer)
    # ------------------------------------------------------------------

    def check_idle(self) -> None:
        """
        Core idle-check callback.  Called every CHECK_INTERVAL_MS milliseconds.
        Reads live config so Apply button changes take immediate effect.
        """
        # Always re-read config from the dataclass in memory (already updated by reload_config).
        cfg = self._cfg
        idle = get_idle_time_seconds()

        if not cfg.enabled:
            return

        if idle > cfg.idle_time and not self._controller.icons_hidden:
            if cfg.mode == "experimental":
                self._controller.fade_hide()
            else:
                self._controller.safe_hide()
            return

        if idle < SHOW_IDLE_THRESHOLD and self._controller.icons_hidden and is_cursor_on_desktop():
            if cfg.mode == "experimental":
                self._controller.fade_show()
            else:
                self._controller.safe_show()
