"""
hoverdesk.py
~~~~~~~~~~~~
HoverDesk – entry point.

Initialises the Qt application, system tray, HoverEngine, and the persistent
SettingsWindow.  All business logic lives in core/; all UI lives in ui/.
"""

from __future__ import annotations

import ctypes
import os
import sys

from PyQt6.QtCore import QObject, QSharedMemory, QTimer
from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtWidgets import QApplication, QMenu, QSystemTrayIcon

from core.config import ConfigStore
from core.engine import HoverEngine
from ui.settings_window import SettingsWindow

APP_NAME = "HoverDesk"
_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


def _icon_path() -> str:
    return os.path.join(_ASSETS_DIR, "icon.png")


def _hide_console_window_if_present() -> None:
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)  # SW_HIDE
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Application controller
# ---------------------------------------------------------------------------

class HoverDeskApp(QObject):
    """
    Top-level controller: owns the tray icon, engine, and settings window.
    Wires all signals — no business logic lives here.
    """

    def __init__(self, app: QApplication) -> None:
        super().__init__()
        print("[HoverDeskApp] Initializing HoverDesk...")
        self._app = app

        # Core
        self._store = ConfigStore()
        self._engine = HoverEngine(self._store)

        # UI (persistent — never recreated after startup)
        print("[HoverDeskApp] Creating MainWindow...")
        self._settings = SettingsWindow(self._engine, self._store)

        # Tray
        print("[HoverDeskApp] Creating tray icon...")
        self._tray = QSystemTrayIcon(QIcon(_icon_path()), self._app)
        self._tray.setToolTip(f"{APP_NAME} — Running")
        self._build_tray_menu()
        self._tray.activated.connect(self._on_tray_activated)
        self._tray.show()

        # Start engine
        cfg = self._store.load()
        if cfg.enabled:
            self._engine.start()

        # Cleanup on quit
        self._app.aboutToQuit.connect(self._engine.shutdown)

    # ------------------------------------------------------------------
    # Tray menu
    # ------------------------------------------------------------------

    def _build_tray_menu(self) -> None:
        # Keep menu reference on self, and explicitly set parent to self
        # to prevent garbage collection and ensure event processing on Windows.
        self._menu = QMenu(parent=self)

        settings_action = QAction("Settings", self)
        settings_action.triggered.connect(self.open_settings)
        self._menu.addAction(settings_action)

        cfg = self._store.load()
        label = "Disable HoverDesk" if cfg.enabled else "Enable HoverDesk"
        self._toggle_action = QAction(label, self)
        self._toggle_action.triggered.connect(self._on_toggle_enabled)
        self._menu.addAction(self._toggle_action)

        self._menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self._app.quit)
        self._menu.addAction(exit_action)

        self._tray.setContextMenu(self._menu)

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.open_settings()

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def open_settings(self) -> None:
        """Defer slightly so the tray menu can close before the window appears."""
        print("[HoverDeskApp] open_settings called.")
        QTimer.singleShot(150, self._settings.show_and_focus)

    def _on_toggle_enabled(self) -> None:
        cfg = self._store.load()
        cfg.enabled = not cfg.enabled
        self._store.save(cfg)

        if cfg.enabled:
            self._engine.start()
            self._toggle_action.setText("Disable HoverDesk")
            self._tray.setToolTip(f"{APP_NAME} — Running")
        else:
            self._engine.stop()
            self._toggle_action.setText("Enable HoverDesk")
            self._tray.setToolTip(f"{APP_NAME} — Disabled")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> int:
    _hide_console_window_if_present()

    print("[Main] Starting HoverDesk process...")

    # Strict single-instance enforcement
    lock = QSharedMemory("HoverDeskAppLock")
    print("[Main] Acquiring single-instance lock 'HoverDeskAppLock'...")
    if lock.attach():
        print("[Main] WARNING: Another instance is already running. Exiting immediately.")
        sys.exit(0)

    # Note: We don't need the return value of create, but calling it holds the lock
    if not lock.create(1):
        print("[Main] ERROR: Failed to create single-instance lock. Exiting.")
        sys.exit(1)

    print("[Main] Lock acquired. Creating QApplication...")
    app = QApplication(sys.argv)
    
    # Store lock reference on app so it isn't garbage collected early
    app._single_instance_lock = lock
    
    app.setQuitOnLastWindowClosed(False)

    print("[Main] Creating HoverDeskApp (controller)...")
    HoverDeskApp(app)
    
    print("[Main] Starting event loop.")
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
